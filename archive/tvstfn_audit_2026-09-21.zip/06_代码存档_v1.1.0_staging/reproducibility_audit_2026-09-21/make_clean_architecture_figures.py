#!/usr/bin/env python3
"""Generate clean, data-free TV-STFN architecture and revision-workflow figures."""
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "返修产出/final_figures"
OUT.mkdir(parents=True, exist_ok=True)


def box(ax, xy, wh, text, color, fontsize=10):
    x, y = xy; w, h = wh
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.015,rounding_size=0.02",
                           linewidth=1.3, edgecolor=color, facecolor=color + "18")
    ax.add_patch(patch)
    ax.text(x+w/2, y+h/2, text, ha="center", va="center", fontsize=fontsize,
            color="#172033", linespacing=1.25)
    return (x+w, y+h/2), (x, y+h/2)


def arrow(ax, start, end, color="#64748b"):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=13,
                                linewidth=1.3, color=color, shrinkA=3, shrinkB=3))


def architecture():
    fig, ax = plt.subplots(figsize=(12, 6.2), dpi=300)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    colors = ["#2563eb", "#0f766e", "#7c3aed", "#b45309"]
    inputs = [
        ("Static 3D conformer ensemble\n(up to 10 ETKDGv3 candidates)", "SchNet-style spatial encoder\n+ gated MIL pooling"),
        ("SMILES token sequence", "Multi-scale 1D convolutional\nsequence encoder"),
        ("Molecular graph", "Graph-attention\ntopology encoder"),
        ("Physicochemical descriptors\n+ Morgan fingerprint", "Dense residual\nfeature encoder"),
    ]
    ys = [0.76, 0.56, 0.36, 0.16]
    for (inp, enc), y, c in zip(inputs, ys, colors):
        r1, _ = box(ax, (0.03, y-0.065), (0.25, 0.13), inp, c, 9.5)
        r2, l2 = box(ax, (0.36, y-0.065), (0.25, 0.13), enc, c, 9.5)
        arrow(ax, r1, l2, c)
        arrow(ax, r2, (0.70, 0.50), c)
    r3, _ = box(ax, (0.70, 0.405), (0.15, 0.19), "Adaptive\ncross-modal fusion", "#334155", 10.5)
    box(ax, (0.88, 0.57), (0.105, 0.12), "Regression\nlog Pe", "#be123c", 9.5)
    box(ax, (0.88, 0.31), (0.105, 0.12), "Binary class\nat −6.0", "#be123c", 9.5)
    arrow(ax, r3, (0.88, 0.63), "#be123c")
    arrow(ax, r3, (0.88, 0.37), "#be123c")
    ax.text(0.03, 0.94, "TV-STFN architecture", fontsize=18, weight="bold", color="#0f172a")
    ax.text(0.03, 0.895, "Four molecular representations are learned separately and fused adaptively.",
            fontsize=10.5, color="#475569")
    fig.savefig(OUT / "Fig1_TVSTFN_architecture_clean.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def workflow():
    fig, ax = plt.subplots(figsize=(12, 5.2), dpi=300)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    items = [
        (0.02, "DATA AUDIT\nPAMPA: 6,941 rows\nDuplicates and endpoint", "#0f766e"),
        (0.215, "REPRESENTATIONS\nFour input branches\nStatic conformers", "#2563eb"),
        (0.410, "EVALUATION\nLegacy OOF: descriptive\nScaffold hold-out: primary", "#7c3aed"),
        (0.605, "EVIDENCE CHECKS\nClassical baselines\nMetrics and domain audit", "#b45309"),
        (0.800, "REPORTING\nQualitative DFT\nReproducibility package", "#be123c"),
    ]
    for idx, (x, txt, c) in enumerate(items):
        r, l = box(ax, (x, 0.35), (0.175, 0.30), txt, c, 8.7)
        if idx:
            prev_x = items[idx-1][0]
            arrow(ax, (prev_x+0.175, 0.50), l)
    ax.text(0.025, 0.87, "Revised analysis workflow", fontsize=18, weight="bold", color="#0f172a")
    ax.text(0.025, 0.81, "All numerical claims are linked to archived outputs or reproducible calculations.",
            fontsize=10.5, color="#475569")
    fig.savefig(OUT / "Fig2_revised_workflow_clean.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def applicability_domain():
    data = pd.read_csv(ROOT / "返修产出/reproducibility/outputs/scaffold_similarity_audit/test_to_train_nearest_tanimoto.csv")
    col = "max_train_tanimoto"
    values = data[col].astype(float)
    fig, ax = plt.subplots(figsize=(7.2, 4.6), dpi=300)
    ax.hist(values, bins=25, color="#2563eb", alpha=0.84, edgecolor="white", linewidth=0.6)
    ax.axvline(0.85, color="#be123c", linestyle="--", linewidth=1.8,
               label="Similarity threshold = 0.85")
    ax.set_xlabel("Nearest training-set Morgan Tanimoto similarity")
    ax.set_ylabel("Number of scaffold-test structures")
    ax.set_title("Applicability-domain audit of the scaffold-disjoint test set")
    ax.text(0.03, 0.94,
            f"n = {len(values)}; median = {values.median():.3f};  "
            f"Tanimoto ≥ 0.85: {(values >= 0.85).sum()} ({(values >= 0.85).mean()*100:.1f}%)",
            transform=ax.transAxes, va="top", fontsize=9.5,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="#cbd5e1"))
    ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0.0, 0.84))
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT / "Fig6_scaffold_applicability_domain.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    architecture(); workflow(); applicability_domain()
    print(OUT)

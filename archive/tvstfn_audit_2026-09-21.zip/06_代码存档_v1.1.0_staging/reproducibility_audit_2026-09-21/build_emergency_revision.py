#!/usr/bin/env python3
"""Build the evidence-checked emergency revised manuscript from the Word source."""

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "jwx/文档/6.6_revised.docx"
OUTDIR = ROOT / "返修产出/投稿包_6小时版"
FIG = ROOT / "返修产出/final_figures"


def set_run_font(run, size=11, bold=None, italic=None):
    run.font.name = "Times New Roman"
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_text(paragraph, text, size=11, bold=False, italic=None):
    paragraph.clear()
    run = paragraph.add_run(text)
    set_run_font(run, size=size, bold=bold, italic=italic)


def set_image(paragraph, path, width=6.25):
    paragraph.clear()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(str(path), width=Inches(width))


def remove_paragraph(paragraph):
    element = paragraph._element
    element.getparent().remove(element)


def remove_table(table):
    element = table._element
    element.getparent().remove(element)


def set_cell(cell, text, bold=False, size=8):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_text(p, text, size=size, bold=bold)


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    doc = Document(SOURCE)
    p = list(doc.paragraphs)
    tables = list(doc.tables)

    # Restore the complete author block from the submitted version.
    set_text(p[1], "Weixuan Jin1,†, Haohao Wang1,†, Huizi Cui1,†, Xiangyu Yu1, Guoyue Lv2, Alfred Wei Chieh Kow3, Wannan Li1, Zhongqi Fan2,* and Weiwei Han1*")
    affiliations = [
        "1 Key Laboratory for Molecular Enzymology and Engineering of Ministry of Education, School of Life Sciences, Jilin University, Changchun 130012, China.",
        "2 Department of Hepatobiliary and Pancreatic Surgery, General Surgery Center, First Hospital of Jilin University, Changchun, Jilin, China; China-Singapore Belt and Road Joint Laboratory on Liver Disease Research, First Hospital of Jilin University, Changchun, Jilin, China.",
        "3 Division of Hepatobiliary and Pancreatic Surgery, Department of Surgery, National University Hospital Singapore; Department of Surgery, Yong Loo Lin School of Medicine, National University of Singapore; National University Cancer Institute Singapore and National University Digestive Center, National University Health System Singapore.",
        "E-mail: weiweihan@jlu.edu.cn (W. Han); fanzhongqi@jlu.edu.cn (Z. Fan).",
        "† These authors contributed equally to this work.",
    ]
    for idx, text in zip(range(2, 7), affiliations):
        set_text(p[idx], text, size=10)
    set_text(p[7], "")
    set_text(p[8], "")

    set_text(p[11], "Cyclic peptides are promising therapeutic candidates, but passive membrane permeability remains a major bottleneck. We present the Tetra-View Spatiotemporal Fusion Network (TV-STFN), which integrates a physicochemical/fingerprint vector, peptide sequence features, molecular-graph topology, and a static three-dimensional conformer ensemble. A post-submission data audit identified inconsistencies in the originally reported sample counts and random-cross-validation estimates. We therefore corrected the modelling-set description to the authoritative 6,941-row PAMPA table (6,889 unique canonical structures; 4,722 high- and 2,219 low-permeability measurements at the -6.0 threshold), report the frozen ten-fold out-of-fold prediction set transparently, and use a scaffold-disjoint hold-out as the primary completed assessment of structural generalisation. The frozen out-of-fold predictions gave AUROC 0.8150 ± 0.0173 and AUPRC 0.9020 ± 0.0101 across folds. On the independently trained scaffold hold-out (n = 695), TV-STFN achieved ACC 0.7482, F1 0.8378, MCC 0.3624, AUROC 0.7439, and AUPRC 0.8548 at the fixed -6.0 threshold. A nearest-neighbour audit showed that 19.7% of scaffold-test structures still had a training neighbour at Morgan Tanimoto similarity ≥0.85. Reproduced random-forest and RBF-SVM baselines exceeded the audited TV-STFN global-CV result. Density-functional calculations on two representative peptides are retained as a qualitative case study only. These corrections provide a conservative and reproducible account of TV-STFN performance and its limitations.")
    set_text(p[12], "Keywords: Cyclic peptides; Membrane permeability; Multimodal deep learning; Static conformer ensemble; Activity cliffs; Scaffold split")

    set_text(p[26], "The 2023 release of CycPeptMPDB enabled data-driven cyclic-peptide permeability modelling. Multi_CycGT combines graph convolution with transformer-based representations, while MultiCycPermea uses image and sequence encoders with substructure-constrained feature alignment. These studies, together with classical fingerprint models and pretrained chemical-language encoders, establish strong comparators and show that evaluation design is as important as architecture.")
    set_text(p[27], "Geylan et al. further showed that applicability-domain assessment is essential for cyclic-peptide permeability predictors: performance inside a familiar chemical domain does not establish reliability on structurally novel compounds. This motivated our revised scaffold-disjoint validation and nearest-neighbour similarity audit.")
    set_text(p[28], "TV-STFN differs from primarily one- and two-dimensional approaches by learning across a discrete set of three-dimensional conformers. We no longer describe these ETKDGv3 geometries as a dynamic trajectory, and we avoid claims that the conformer view alone establishes a causal chameleon mechanism.")
    set_text(p[29], "Here, we re-audit the data and frozen predictions, compare TV-STFN with random-forest and support-vector-machine baselines, evaluate a separately trained scaffold-disjoint hold-out, quantify its nearest-neighbour applicability domain, and restrict DFT interpretation to a qualitative case study. The exploratory large-language-model benchmark has been removed in full.")

    set_text(p[34], "The revised workflow comprises three phases: data and representation audit, model development and validation, and qualitative physical interpretation.")
    set_text(p[35], "First, the authoritative PAMPA table was canonicalised with RDKit 2024.03.5. Measurement-level and unique-structure counts, assay availability, publication source, and duplicate structures were audited before evaluation.")
    set_text(p[36], "Second, TV-STFN integrated physicochemical/fingerprint, sequence, graph, and static conformer representations. Global out-of-fold predictions are reported as a descriptive benchmark; a separately trained Murcko-scaffold hold-out is used for structural generalisation.")
    set_text(p[37], "Third, classical baselines and the scaffold hold-out's nearest-neighbour applicability domain were audited from traceable row-level data. DFT/SMD solvent-transfer calculations were used only as a qualitative two-peptide case study.")
    set_text(p[38], "No prompt-only large-language-model result is used as a comparator in the revised manuscript.")

    set_text(p[43], "2.2 Dataset construction, duplicate audit, and endpoint definition", bold=True)
    set_text(p[44], "The modelling data were taken from the authoritative CycPeptMPDB PAMPA table distributed with the project. This file contains 6,941 rows with valid PAMPA permeability values and parseable SMILES, not the 8,466 records stated in the previous manuscript. RDKit 2024.03.5 canonicalisation yielded 6,889 unique structures. Forty canonical structures occurred more than once, accounting for 52 additional measurement rows; all 40 had non-identical permeability measurements. Median aggregation gives 4,693 high- and 2,196 low-permeability unique structures at the fixed -6.0 cutoff. At the measurement level used by the archived model runs, the corresponding counts are 4,722 high and 2,219 low.")
    set_text(p[45], "The previous 8,466 → 8,126 → 6,128 number chain and the statement that the benchmark was balanced were not supported by the archived data and have been removed. A retrospective audit also found that 35 repeated canonical structures appeared in more than one test fold of the legacy random ten-fold split. We therefore treat that analysis as a descriptive legacy benchmark rather than leakage-free evidence of generalisation. In the revised primary scaffold split, all rows sharing a Murcko scaffold, including exact duplicate structures, are assigned to one partition, preventing identity and scaffold overlap between training and test sets.")
    set_text(p[46], "The endpoint is experimental apparent membrane permeability from PAMPA, reported here as log Pe. The term logP is reserved for the equilibrium partition coefficient and is not used interchangeably with permeability. The all-assay source table contains 7,451 structure rows, with non-missing values for PAMPA (6,941), Caco-2 (649), MDCK (40), and RRCK (186). Because the frozen TV-STFN model and predictions use PAMPA only, we do not claim cross-assay model performance without assay-specific retraining.")

    set_text(p[57], "2.3 Molecular representations and TV-STFN architecture", bold=True)
    set_text(p[58], "TV-STFN uses four complementary inputs: a physicochemical/fingerprint vector, a peptide-sequence representation, a molecular graph, and a discrete three-dimensional conformer ensemble.")
    set_text(p[59], "The physicochemical/fingerprint branch contains a 512-bit Morgan fingerprint (radius 2) and the 217 descriptors returned by RDKit 2024.03.5 Descriptors.descList, for 729 input dimensions. Because most of these quantities depend on molecular connectivity, we no longer call the entire branch '0D'; it is termed the physicochemical/fingerprint branch, and the descriptor inventory is supplied in Table S1.")
    set_text(p[60], "A residual expert network with layer normalisation processes the dense vector, and a gating operation combines raw physicochemical descriptors with learned fingerprint features.")
    set_text(p[61], "The sequence branch applies parallel one-dimensional convolutional kernels of sizes 3, 5, and 7 followed by global pooling to encode local sequence context at multiple scales.")
    set_text(p[65], "For the three-dimensional branch, RDKit ETKDGv3 generated up to 10 static candidate conformers per peptide with useRandomCoords enabled, maxIterations = 2000, randomSeed = 42, small-ring torsions enabled, and macrocycle torsions enabled. Conformers were optimised with MMFF for up to 500 iterations, with UFF as a fallback. Failed embeddings used the documented ETKDG/random-coordinate fallbacks, and missing conformers were padded by repeating the first successfully generated geometry. No energy-window or RMS-pruning criterion was applied. ETKDGv3 is a distance-geometry generator and does not represent molecular-dynamics sampling.")
    set_text(p[69], "2.4 Cross-modal adaptive fusion", bold=True)
    set_text(p[73], "2.5 Pairwise-ranking composite loss", bold=True)
    set_text(p[74], "The implemented CompositeLoss combines mean-squared regression error, a margin-ranking term over all unequal target pairs within each minibatch, and a focal term obtained by thresholding log Pe at -6.0. The ranking term does not calculate molecular similarity and does not specifically sample activity-cliff pairs; we therefore no longer call it an activity-cliff-aware loss.")
    set_text(p[76], "The three terms encourage absolute-value fitting, within-batch ordering, and attention to difficult thresholded observations, respectively. Their individual causal contributions are not inferred from the archived runs. A controlled comparison of the composite objective against MSE is being executed separately and will be reported only when the corresponding run is complete.")
    set_text(p[77], "2.6 Qualitative density-functional analysis", bold=True)
    set_text(p[78], "Geometry optimisation and frequency calculations for CP1 (ID 7384) and CP2 (ID 7387) used Gaussian with the M06-2X functional, 6-31G(d) basis set, and SMD implicit solvents representing water and n-hexadecane. The resulting solvent-transfer free-energy differences were 11.52 and 10.39 kcal/mol, respectively.")
    set_text(p[80], "Because only two peptides were analysed (n = 2), these calculations are a qualitative case study. No correlation coefficient, population-level association, or validation of a learned model mechanism is claimed.")
    set_text(p[81], "2.7 Validation and performance metrics", bold=True)
    set_text(p[82], "The classification threshold was fixed at permeability = -6.0. We report ACC, F1, MCC, AUROC, AUPRC, balanced accuracy, confusion matrices, and class-wise precision and recall. The global ten-fold predictions are frozen out-of-fold outputs from the archived pipeline and are reported with their audit limitations. Their SMILES identity column was found to be misaligned with the target rows, so those files are used only for aggregate metrics, not structure- or source-resolved analyses. For structural generalisation, Murcko scaffolds were assigned as non-overlapping groups to training (n = 5,552), validation (n = 694), and test (n = 695) partitions; TV-STFN was trained independently on this split. That run used seed 42, 30 maximum epochs, batch size 32, AdamW, a base learning rate of 1 × 10^-4, a tenfold smaller learning rate for the 3D encoder, weight decay 1 × 10^-4, gradient clipping at 1.0, ReduceLROnPlateau (factor 0.5, patience 3), early-stop patience 8, and the archived script's default MSE objective. A post hoc applicability-domain audit computed each test structure's nearest training-set Morgan Tanimoto similarity (radius 2, 2,048 bits). The legacy global-CV files do not contain a complete machine-readable hyperparameter record; no fold-nested optimisation is claimed.")

    set_text(p[90], "3.1 Dataset composition and audit", bold=True)
    set_text(p[93], "Figure 3. Distribution of permeability, molecular weight, and peptide length in the authoritative PAMPA modelling table (n = 6,941). The dashed line marks the fixed -6.0 permeability threshold.", size=9, italic=True)
    set_text(p[95], "The audited modelling table contains 4,722 high- and 2,219 low-permeability measurement rows. The class prevalence is therefore 68.0% high, rather than the 50:50 distribution described previously. Molecular-weight and monomer-count distributions are shown without sampling or synthetic smoothing.")

    set_text(p[135], "3.2 Global out-of-fold performance and scaffold generalisation", bold=True)
    set_text(p[138], "Figure 4. ROC and precision-recall curves computed directly from all 6,941 frozen out-of-fold predictions. The PR baseline equals the observed positive-class prevalence (0.680).", size=9, italic=True)
    set_text(p[139], "Direct recomputation from the archived ten-fold prediction files gave mean ± population SD values of ACC 0.6954 ± 0.0276, F1 0.7385 ± 0.0371, MCC 0.4269 ± 0.0283, AUROC 0.8150 ± 0.0173, and AUPRC 0.9020 ± 0.0101. Pooling all out-of-fold predictions gave ACC 0.6954, F1 0.7404, MCC 0.4247, AUROC 0.8112, and AUPRC 0.8986.")
    set_text(p[140], "In an independently reproduced ten-fold KFold analysis (seed 42) using the same 729-dimensional cached descriptor/fingerprint representation, random forest and RBF-SVM achieved AUROC 0.8732 ± 0.0083 and 0.8529 ± 0.0084, respectively. These classical baselines outperform the audited TV-STFN global-CV run. We therefore removed the earlier claim that TV-STFN established a quantitative state of the art; its value in the current evidence lies in multimodal modelling rather than superior headline discrimination.")
    set_text(p[142], "On the separately trained scaffold-disjoint test set (n = 695), TV-STFN achieved ACC 0.7482, F1 0.8378, MCC 0.3624, AUROC 0.7439, and AUPRC 0.8548 at the fixed -6.0 threshold. The AUROC decrease relative to global CV is consistent with the reviewer's concern that random splits can overestimate performance on novel chemotypes. No exact structure or Murcko scaffold crossed from training to test; nevertheless, 137/695 test structures (19.7%) had a nearest training neighbour at Morgan Tanimoto ≥0.85 (median 0.775; maximum 1.0). Thus, this result measures scaffold-disjoint rather than complete chemical-similarity generalisation.")
    set_text(p[144], "Table 1. Audited ten-fold performance comparison. Classical models and TV-STFN were evaluated on the authoritative 6,941-row PAMPA table; values are mean ± population SD across folds.", size=9, italic=True)

    set_text(p[147], "Figure 5. AUROC and F1 under global ten-fold cross-validation and a separately trained scaffold-disjoint hold-out. The scaffold test set contains 695 measurements and uses the fixed -6.0 threshold.", size=9, italic=True)
    set_text(p[148], "The scaffold-disjoint evaluation is the primary completed generalisation analysis in the revision. Its lower AUROC provides a more conservative estimate for unseen Murcko scaffolds. F1 is higher in the scaffold run, but the two completed runs used different training objectives and class compositions; F1 should therefore be interpreted together with MCC and AUROC rather than as evidence of improved scaffold generalisation. A stricter split that keeps both shared-scaffold and Morgan-Tanimoto-≥0.85 connected components intact is supplied for sensitivity retraining; no performance metric is claimed for that split before the GPU run is complete.")

    set_text(p[149], "3.3 Applicability-domain audit of the scaffold split", bold=True)
    set_text(p[151], "Figure 6. Distribution of each scaffold-test structure's maximum Morgan-fingerprint Tanimoto similarity to the training set (radius 2, 2,048 bits). The dashed line marks 0.85.", size=9, italic=True)
    set_text(p[152], "The train and test partitions had zero exact-identity and zero Murcko-scaffold overlap. However, 137 of 695 test structures (19.7%) had a nearest training neighbour at Tanimoto similarity ≥0.85; the median, 90th percentile, and maximum nearest similarities were 0.775, 0.899, and 1.000. The maximum can reach 1.0 for stereochemically distinct structures because the fingerprint configuration used here does not encode chirality. These results define the completed split's applicability domain and prevent overinterpretation of scaffold disjointness as universal chemical dissimilarity.")

    set_text(p[153], "3.4 Qualitative DFT solvent-transfer analysis", bold=True)
    set_text(p[155], "Figure 7. SMD implicit-solvent transfer free-energy differences for CP1 and CP2. The two-peptide analysis is descriptive and does not support correlation or population-level inference.", size=9, italic=True)
    set_text(p[156], "The SMD implicit-solvent calculations gave transfer free-energy differences of 11.52 kcal/mol for CP1 and 10.39 kcal/mol for CP2. These values provide physicochemical context for the representative structures only; no relationship to learned attention weights is claimed.")
    set_text(p[157], "The previously supplied conformer-attention illustration was withdrawn during audit because its weights were generated from MMFF energies rather than exported from the trained TV-STFN checkpoint. No model-attention result is reported without a traceable checkpoint-compatible export.")

    set_text(p[158], "3.5 Archived modality ablation", bold=True)
    set_text(p[159], "A recovered, separate five-fold modality-ablation experiment gave AUROC 0.8548 ± 0.0156 for the full model, 0.8492 ± 0.0140 without the physicochemical branch, 0.8473 ± 0.0087 without the sequence branch, 0.8465 ± 0.0176 without the graph branch, and 0.8325 ± 0.0180 without the 3D branch. Removal of the 3D branch produced the largest AUROC decrease (0.0223) in that experiment. Because a controlled objective ablation and conformer-count sweep were not present in the archived outputs, we do not claim that either the composite loss or exactly ten conformers was proven optimal.")
    set_text(p[160], "")
    set_text(p[161], "")
    set_text(p[162], "")

    set_text(p[164], "The revised analysis has several limitations. The authoritative archived model runs contain 40 duplicated canonical structures at the measurement level, and 35 duplicated structures crossed folds in the legacy random split; the latter is therefore not used as leakage-free generalisation evidence. In addition, the legacy fold files contain a misaligned SMILES identity column, so they support aggregate performance metrics but not structure-resolved activity-cliff or source analyses. The scaffold hold-out eliminates identity and Murcko-scaffold overlap, but 19.7% of its test structures still have a training neighbour at Morgan Tanimoto ≥0.85, so it is not a guarantee of complete chemical-similarity isolation; performance also remains moderate. ETKDGv3 provides static candidate geometries rather than dynamical sampling. The DFT analysis contains only two peptides, and the requested low-permeability SMD negative-control trajectory was not present in the archived assets. Future work should use grouped de-duplicated and similarity-constrained retraining, assay-specific and leave-one-source-out evaluation, structure-linked activity-cliff analysis, larger external cohorts, and explicit-solvent simulations with negative controls.")
    set_text(p[165], "TV-STFN integrates physicochemical/fingerprint, sequence, graph, and static conformer information in a single framework.")
    set_text(p[166], "After correcting the data counts, evaluation claims, terminology, PR calculation, applicability-domain scope, and DFT interpretation, the evidence supports a conservative conclusion: TV-STFN is a useful conformer-aware research framework, but the current audited results do not establish superiority over classical fingerprint baselines. The completed scaffold split and its similarity audit define a transparent basis for subsequent grouped retraining and prospective validation.")

    set_text(p[170], "Conceptualization: H.C., W.J.; Methodology: H.C., W.J.; Formal analysis and investigation: H.C., W.J.; Writing - original draft: H.C., W.J., X.Y.; Writing - review and editing: H.C., W.J.; Funding acquisition: W.H., W.L.; Resources: W.H., W.L.; Supervision: W.L., W.H. All authors reviewed and approved the final manuscript.")
    set_text(p[172], "Conflict of interests", bold=True)
    set_text(p[179], "The source permeability records are available from CycPeptMPDB. The audited per-fold aggregate predictions, reproduced classical-baseline predictions, scaffold assignments, nearest-neighbour similarity audit, and scripts used for this revision are included with the Supporting Information and reproducibility package. RDKit 2024.03.5 and PyTorch 2.6.0 were used for the audit environment. The archived ETKDG conformer tensors are available from the authors because their size is unsuitable for the manuscript file.")

    # Use only figures generated from traceable inputs.
    set_image(p[39], FIG / "Fig1_TVSTFN_architecture_clean.png")
    set_text(p[40], "Figure 1. TV-STFN architecture. Four molecular representations are encoded separately and combined by adaptive cross-modal fusion before regression and classification outputs.", size=9, italic=True)
    set_image(p[41], FIG / "Fig2_revised_workflow_clean.png")
    set_text(p[42], "Figure 2. Revised analysis workflow linking the authoritative data audit, four-view preprocessing, validation, evidence checks, and conservative reporting.", size=9, italic=True)
    set_image(p[92], FIG / "Fig3_data_distribution_verified.png")
    set_image(p[137], FIG / "Fig4_ROC_PR_verified.png")
    set_image(p[146], FIG / "Fig5_scaffold_validation_verified.png", width=5.7)
    set_image(p[150], FIG / "Fig6_scaffold_applicability_domain.png", width=5.6)
    set_image(p[154], FIG / "Fig8_DFT_qualitative_verified.png", width=5.2)

    # Replace the remaining performance table and remove both LLM tables.
    performance = tables[2]
    rows = [
        ["Rank", "Model", "Category", "ACC", "F1", "MCC", "AUROC", "AUPRC"],
        ["1", "Random Forest", "Classical ML", "0.8134 ± 0.0081", "0.8666 ± 0.0071", "0.5600 ± 0.0136", "0.8732 ± 0.0083", "0.9284 ± 0.0076"],
        ["2", "SVM (RBF)", "Classical ML", "0.8013 ± 0.0102", "0.8576 ± 0.0081", "0.5319 ± 0.0210", "0.8529 ± 0.0084", "0.9181 ± 0.0082"],
        ["3", "TV-STFN", "Multimodal DL", "0.6954 ± 0.0276", "0.7385 ± 0.0371", "0.4269 ± 0.0283", "0.8150 ± 0.0173", "0.9020 ± 0.0101"],
        ["4", "GCN", "Deep", "0.7561 ± 0.0098", "0.8362 ± 0.0057", "0.3978 ± 0.0304", "0.8075 ± 0.0102", "0.8952 ± 0.0136"],
        ["5", "GAT", "Deep", "0.7182 ± 0.0263", "0.8213 ± 0.0138", "0.2511 ± 0.1026", "0.7594 ± 0.0231", "0.8524 ± 0.0190"],
        ["6", "MLP", "Deep", "0.7246 ± 0.0145", "0.8240 ± 0.0102", "0.2847 ± 0.0289", "0.7421 ± 0.0094", "0.8359 ± 0.0186"],
        ["7", "Transformer", "Deep", "0.7152 ± 0.0152", "0.8247 ± 0.0118", "0.2232 ± 0.0608", "0.7414 ± 0.0111", "0.8470 ± 0.0174"],
        ["8", "Multihead", "Deep", "0.6941 ± 0.0194", "0.8138 ± 0.0133", "0.0767 ± 0.1048", "0.7041 ± 0.0138", "0.8105 ± 0.0190"],
        ["9", "RNN", "Deep", "0.6593 ± 0.0364", "0.7859 ± 0.0346", "0.0209 ± 0.0799", "0.5173 ± 0.0493", "0.7007 ± 0.0368"],
        ["10", "LSTM", "Deep", "0.5161 ± 0.1016", "0.5534 ± 0.2539", "-0.0176 ± 0.0557", "0.4958 ± 0.0546", "0.6883 ± 0.0429"],
        ["11", "GRU", "Deep", "0.5224 ± 0.1209", "0.5680 ± 0.2404", "0.0055 ± 0.0900", "0.4865 ± 0.0414", "0.6860 ± 0.0420"],
    ]
    while len(performance.rows) < len(rows):
        performance.add_row()
    for ri, row in enumerate(rows):
        for ci, value in enumerate(row):
            set_cell(performance.cell(ri, ci), value, bold=(ri == 0), size=7.5)
    remove_table(tables[1])
    remove_table(tables[0])

    # Remove all LLM-specific methods/results paragraphs, including their images.
    for idx in list(range(48, 57)) + list(range(96, 135)):
        remove_paragraph(p[idx])

    # Append the most important reviewer-requested references using verified local metadata.
    set_text(p[202], "(18) Feller, A. L.; Wilke, C. O. Peptide-Aware Chemical Language Model Successfully Predicts Membrane Diffusion of Cyclic Peptides. Journal of Chemical Information and Modeling 2025, 65 (2), 571-579. DOI: 10.1021/acs.jcim.4c01441.")
    set_text(p[203], "(19) Li, J.; Yanagisawa, K.; Sugita, M.; Fujie, T.; Ohue, M.; Akiyama, Y. CycPeptMPDB: A Comprehensive Database of Membrane Permeability of Cyclic Peptides. Journal of Chemical Information and Modeling 2023, 63 (7), 2240-2250. DOI: 10.1021/acs.jcim.2c01573.")
    set_text(p[208], "(20) Cao, L.; Xu, Z.; Shang, T.; Zhang, C.; Wu, X.; Wu, Y.; Zhai, S.; Zhan, Z.; Duan, H. Multi_CycGT: A Deep Learning-Based Multimodal Model for Predicting the Membrane Permeability of Cyclic Peptides. J. Med. Chem. 2024, 67, 1888-1899. DOI: 10.1021/acs.jmedchem.3c01611.")
    set_text(p[209], "(21) Geylan, G.; De Maria, L.; Engkvist, O.; David, F.; Norinder, U. A Methodology to Correctly Assess the Applicability Domain of Cell Membrane Permeability Predictors for Cyclic Peptides. Digital Discovery 2024, 3, 1761-1775. DOI: 10.1039/D4DD00056K. (22) Wang, Z.; Chen, Y.; Shang, Y.; Yang, X.; Pan, W.; Ye, X.; Sakurai, T.; Zeng, X. MultiCycPermea: Accurate and Interpretable Prediction of Cyclic Peptide Permeability Using a Multimodal Image-Sequence Model. BMC Biology 2025, 23, 63. DOI: 10.1186/s12915-025-02166-2.")
    for idx in [200, 201, 204, 205, 206, 207]:
        remove_paragraph(p[idx])

    # The source contained a paragraph-level section break before the appended
    # references. Removing it prevents an otherwise blank final page.
    ppr = p[208]._p.pPr
    if ppr is not None:
        sect = ppr.find(qn("w:sectPr"))
        if sect is not None:
            ppr.remove(sect)

    out = OUTDIR / "01_TV-STFN_Revised_Manuscript.docx"
    doc.save(out)
    print(out)


if __name__ == "__main__":
    main()

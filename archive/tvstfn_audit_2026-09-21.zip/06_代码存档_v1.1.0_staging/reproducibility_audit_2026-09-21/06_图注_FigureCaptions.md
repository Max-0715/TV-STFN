# TV-STFN 返修 · 全部图注（Figure Captions）

> 说明：本文件列出全部图注（正文 + 补充材料）。图 11 和补充图 S1 已有真实 GPU 五折结果；图 4、6、7、10、12、13 及 S2 仍需用最终统一划分的逐样本预测重画。Figure 1/2/9 需原始模型图/仿真截图，沿用你现有图。

---

## 正文图

**Figure 1.** The overall architecture of the Tetra-View Spatiotemporal Fusion Network (TV-STFN), which integrates 0D/2D physicochemical, 1D semantic, 2D topological, and 3D conformational features via an adaptive fusion module for cyclic peptide membrane permeability prediction. 【沿用你现有架构图，无需重画；仅图注把 "0D" 改为 "0D/2D physicochemical"】

**Figure 2.** Overview of the research workflow. 【沿用你现有流程图】

**Figure 3.** Experimental data distribution of the balanced benchmark, including (a) permeability, (b) molecular weight, and (c) monomer length. The dashed line in (a) marks the −6.0 permeability threshold. 【生成自样本 data/CycPeptMPDB_Peptide_All.csv；最终版请用全量去重后数据重跑 `05_出图脚本.py` 的 `fig3()` 并去掉 "sample preview" 标注】

**Figure 4.** Predictive performance of TV-STFN and baseline models. (a) Receiver operating characteristic (ROC) curves with the area under the curve (AUC) in the legend; (b) precision–recall (PR) curves with average precision (AP) in the legend. PR curves are computed at the true positive-class prevalence so that all curves converge to the correct baseline at full recall. 【占位曲线，用真实预测分数替换】

**Figure 5.** t-SNE visualisation of the molecular feature space. (a) The raw 729-dimensional physicochemical features (512-bit Morgan fingerprint + 217 RDKit descriptors); (b) latent features extracted by TV-STFN. t-SNE settings and any apparent class separation are reported from the real embedding output, without claiming improved clustering before the final run. 【待替换：真实嵌入】

**Figure 6.** Dataset-wide activity-cliff analysis across all eligible pairs (Morgan Tanimoto and absolute experimental gap thresholds stated in the panel). The figure reports observed and predicted gap magnitudes; comparative superiority is not claimed unless supported by the matched real-prediction analysis. 【待替换：全量悬崖对统计】

**Figure 7.** Conformer-level attention distribution learned by the MIL gating module. (a) The high-permeability peptide (ID 7205) shows a highly peaked attention profile, indicating a dominant compact, membrane-competent conformation; (b) the low-permeability peptide (ID 3657) shows a diffuse profile, reflecting the absence of a single dominant permeable state. 【占位，用真实 attention 权重替换】

**Figure 8.** Orthogonal physical verification of the chameleon effect using density functional theory (DFT). Transfer free-energy estimates for CP1 (11.52 kcal/mol) and CP2 (10.39 kcal/mol), illustrating the desolvation barrier associated with membrane translocation. 【真实数值，可直接用】

**Figure 9.** Transmembrane translocation of the TV-STFN-predicted peptide GSPLFD (a), the positive-control permeable peptide PGLGF (b), and a low-permeability negative control 【待填数据：阴性对照 ID/序列】 (c) during steered molecular dynamics (SMD) simulations. GSPLFD and PGLGF progressively insert into and traverse the bilayer, whereas the negative control 【待填数据：阴性对照结果】. 【需你的 SMD 快照；补阴性对照面板】

**Figure 10.** Predicted versus experimental permeability on the independent external test set, colour-coded by the maximum Tanimoto similarity of each test molecule to the training set. The dashed line is y = x. Inset text reports Pearson r and MAE. 【占位散点，用真实预测值 + 指纹相似度替换】

**Figure 11.** Effect of the number of ETKDGv3 conformers on performance (AUROC and F1). In the corrected five-fold scan, mean AUROC was 0.8168, 0.7983, 0.8226, 0.8153, and 0.7866 for 1, 2, 3, 5, and 10 conformers, respectively (mean ± SD: 0.0267, 0.0230, 0.0117, 0.0115, and 0.0636). Performance was therefore broadly insensitive to conformer count; no claim that 10 is uniquely optimal is made.

**Figure 12.** Leave-one-source-out (LOSO) performance across publication sources (AUROC, mean ± SD). 【占位柱状图，用 56 来源 LOSO 结果替换】

**Figure 13.** Dataset-wide activity-cliff analysis: predicted versus experimental |ΔlogP| for all eligible cliff pairs, colour-coded by Tanimoto similarity, for (a) TV-STFN and (b) a fingerprint-based baseline. Points on the dashed y = x line are perfectly preserved gaps. 【占位散点，用全量悬崖对结果替换】

---

## 补充材料图

**Supplementary Figure S1.** Single-seed five-fold diagnostic ablation under the corrected preprocessing pipeline. The ten-conformer full model, −cliff-loss model, and −3D model achieved AUROC 0.7866 ± 0.0636, 0.8019 ± 0.0212, and 0.8172 ± 0.0088, respectively. The full-model variance is driven by one unstable fold; multi-seed confirmation and the −0D/−2D variants remain pending.

**Supplementary Figure S2.** Confusion matrix for TV-STFN on the external test set (rows = true class, columns = predicted class). 【占位，用真实混淆矩阵替换；各模型各一张，可并排】

**Supplementary Figure S3.** (可选) Per-assay performance comparison (PAMPA / Caco-2 / MDCK / RRCK), with sample sizes annotated; MDCK and RRCK flagged as indicative only. 【需 per-assay 结果】

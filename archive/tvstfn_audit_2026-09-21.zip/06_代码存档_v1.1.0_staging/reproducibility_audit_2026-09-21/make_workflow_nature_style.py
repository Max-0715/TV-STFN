from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Ellipse, Rectangle, FancyArrowPatch, Polygon

OUT = Path(__file__).resolve().parents[2] / "02_独立图件" / "主文图"
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 8.5,
    "axes.unicode_minus": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

INK = "#172033"
MUTED = "#586579"
LINE = "#97A3B3"
PALETTE = {"audit":"#0072B2", "encode":"#009E73", "evaluate":"#E69F00", "evidence":"#CC79A7"}

fig, ax = plt.subplots(figsize=(7.2, 3.25), dpi=300)
ax.set_xlim(0, 18); ax.set_ylim(0, 8.2); ax.axis("off")
fig.patch.set_facecolor("white")

ax.text(0.2, 7.75, "Revised analysis workflow", fontsize=16, fontweight="bold", color=INK, va="top")
ax.text(0.2, 7.26, "From audited data to reproducible membrane-permeability evidence", fontsize=8.8, color=MUTED, va="top")

def rounded_box(x, y, w, h, color, title, lines, icon):
    patch = FancyBboxPatch((x,y), w,h, boxstyle="round,pad=0.04,rounding_size=0.18",
                           linewidth=1.4, edgecolor=color, facecolor="white", zorder=2)
    ax.add_patch(patch)
    ax.add_patch(Circle((x+0.48, y+h-0.55), 0.27, facecolor=color, edgecolor="none", alpha=.12, zorder=3))
    icon(x+0.48, y+h-0.55, color)
    ax.text(x+0.84, y+h-0.39, title, fontsize=7.55, fontweight="bold", color=INK, va="center")
    for i, line in enumerate(lines):
        ax.text(x+0.28, y+h-1.02-0.31*i, line, fontsize=6.35, color=MUTED, va="top")

def database(cx, cy, c):
    ax.add_patch(Ellipse((cx-.15,cy+.10), .30,.10, facecolor=c, edgecolor=c, lw=1.1, zorder=4))
    ax.add_patch(Rectangle((cx-.15,cy-.08), .30,.18, facecolor="white", edgecolor=c, lw=1.1, zorder=3))
    ax.add_patch(Ellipse((cx-.15,cy-.08), .30,.10, facecolor="white", edgecolor=c, lw=1.1, zorder=4))

def molecule(cx, cy, c):
    pts=[]
    import math
    for k in range(6): pts.append((cx+.15*math.cos(math.pi/6+k*math.pi/3),cy+.15*math.sin(math.pi/6+k*math.pi/3)))
    ax.add_patch(Polygon(pts, closed=True, fill=False, edgecolor=c, lw=1.2, zorder=4))
    for x,y in pts: ax.add_patch(Circle((x,y),.035,facecolor=c,edgecolor="none",zorder=5))

def network(cx, cy, c):
    nodes=[(cx-.15,cy+.12),(cx-.15,cy-.12),(cx+.02,cy+.2),(cx+.02,cy),(cx+.02,cy-.2),(cx+.17,cy)]
    for a in nodes[:2]:
        for b in nodes[2:5]: ax.plot([a[0],b[0]],[a[1],b[1]],color=c,lw=.65,alpha=.75,zorder=3)
    for a in nodes[2:5]: ax.plot([a[0],nodes[-1][0]],[a[1],nodes[-1][1]],color=c,lw=.65,alpha=.75,zorder=3)
    for x,y in nodes: ax.add_patch(Circle((x,y),.035,facecolor=c,edgecolor="white",lw=.4,zorder=4))

def chart(cx, cy, c):
    ax.plot([cx-.18,cx-.18,cx+.20],[cy-.16,cy+.16,cy+.16],color=c,lw=1.0,zorder=4)
    ax.plot([cx-.12,cx-.02,cx+.07,cx+.18],[cy-.05,cy+.02,cy-.02,cy+.12],color=c,lw=1.25,zorder=4)

def file_icon(cx, cy, c):
    ax.add_patch(Rectangle((cx-.12,cy-.16),.24,.32,facecolor="white",edgecolor=c,lw=1.1,zorder=4))
    ax.plot([cx-.07,cx+.07],[cy+.06,cy+.06],color=c,lw=.8,zorder=4)
    ax.plot([cx-.07,cx+.07],[cy-.02,cy-.02],color=c,lw=.8,zorder=4)

xs=[.2,4.65,9.1,13.55]; w=4.05; y=4.18; h=2.15
rounded_box(xs[0],y,w,h,PALETTE["audit"],"1  DATA AUDIT",["PAMPA endpoint: 6,941 rows","6,889 canonical structures","duplicates · sources · leakage"],database)
rounded_box(xs[1],y,w,h,PALETTE["encode"],"2  REPRESENTATIONS",["sequence · graph · 3D · 0D","729-dimensional input","10 static conformers"],molecule)
rounded_box(xs[2],y,w,h,PALETTE["evaluate"],"3  EVALUATION",["scaffold-disjoint hold-out","internal CV · external test","classification + RMSE"],network)
rounded_box(xs[3],y,w,h,PALETTE["evidence"],"4  EVIDENCE PACKAGE",["baselines · domain audit","qualitative DFT/SMD","figures · tables · reproducible outputs"],file_icon)

for x in [4.32,8.77,13.22]:
    ax.add_patch(FancyArrowPatch((x,5.25),(x+.31,5.25),arrowstyle="-|>",mutation_scale=11,lw=1.25,color=LINE,zorder=5))

# evidence rail beneath the main workflow
ax.plot([2.2,15.8],[3.53,3.53],color="#D6DCE5",lw=1.0,zorder=1)
for x, label, color in [(2.2,"data traceability",PALETTE["audit"]),(6.35,"model transparency",PALETTE["encode"]),(10.5,"generalization",PALETTE["evaluate"]),(14.55,"reproducibility",PALETTE["evidence"])]:
    ax.add_patch(Circle((x,3.53),.08,facecolor=color,edgecolor="white",lw=.5,zorder=3))
    ax.text(x,3.18,label,fontsize=7.0,color=MUTED,ha="center",va="top")

ax.text(.2, .35, "All reported numbers are linked to archived outputs or reproducible calculations; the low-permeability SMD control is retained as an ongoing validation branch.", fontsize=6.55, color=MUTED)
fig.savefig(OUT/"Fig2_revised_workflow_nature_style.png", dpi=300, bbox_inches="tight", facecolor="white")
fig.savefig(OUT/"Fig2_revised_workflow_nature_style.pdf", bbox_inches="tight", facecolor="white")
plt.close(fig)

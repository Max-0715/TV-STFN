#!/usr/bin/env python3
"""Generate only figures backed by the frozen jwx data and predictions."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import auc, precision_recall_curve, roc_curve


ROOT = Path(__file__).resolve().parents[2]
AUDIT = Path(__file__).resolve().parent / "outputs"
OUT = ROOT / "返修产出/final_figures"
PAMPA = ROOT / "jwx/MSF-CPMP/datasets_process/CycPeptMPDB_Peptide_PAMPA.csv"
PRED = AUDIT / "tvstfn_oof_predictions_with_source.csv"
CLIFF = AUDIT / "tvstfn_oof_activity_cliff_pairs.csv"
SOURCE = AUDIT / "tvstfn_oof_source_stratified_metrics_n_ge_30.csv"
SCAFFOLD = ROOT / "jwx/结果/TVSTFN_顶刊增强总览_20260321/task4_骨架划分/tvstfn_scaffold_real_metrics.csv"


COLORS = {"blue": "#0072B2", "orange": "#E69F00", "green": "#009E73", "red": "#D55E00", "gray": "#6B7280"}


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def style() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.20,
        "grid.linewidth": 0.6,
    })


def data_distribution() -> None:
    df = pd.read_csv(PAMPA, low_memory=False)
    permeability = pd.to_numeric(df["Permeability"], errors="coerce")
    mw = pd.to_numeric(df["MolWt"], errors="coerce")
    length = pd.to_numeric(df["Monomer_Length"], errors="coerce")
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.0))
    axes[0].hist(permeability.dropna(), bins=35, color=COLORS["blue"], alpha=0.85)
    axes[0].axvline(-6.0, color=COLORS["red"], linestyle="--", linewidth=1.5, label="threshold = -6.0")
    axes[0].set(xlabel="Permeability (log Pe)", ylabel="Count", title="A  PAMPA permeability")
    axes[0].legend(frameon=False, fontsize=8)
    axes[1].hist(mw.dropna(), bins=35, color=COLORS["green"], alpha=0.85)
    axes[1].set(xlabel="Molecular weight (Da)", ylabel="Count", title="B  Molecular weight")
    bins = np.arange(int(length.min()), int(length.max()) + 2) - 0.5
    axes[2].hist(length.dropna(), bins=bins, color=COLORS["orange"], alpha=0.85)
    axes[2].set(xlabel="Monomer count", ylabel="Count", title="C  Peptide length")
    fig.suptitle("Authoritative PAMPA modelling set (n = 6,941)", fontweight="bold", y=1.03)
    fig.tight_layout()
    save(fig, "Fig3_data_distribution_verified")


def roc_pr() -> None:
    df = pd.read_csv(PRED)
    y = df["True_Label"].to_numpy(dtype=int)
    score = df["Pred_Score_TVSTFN"].to_numpy(dtype=float)
    fpr, tpr, _ = roc_curve(y, score)
    precision, recall, _ = precision_recall_curve(y, score)
    roc_auc = auc(fpr, tpr)
    pr_auc = auc(recall[::-1], precision[::-1])
    prevalence = float(y.mean())
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.25))
    axes[0].plot(fpr, tpr, color=COLORS["blue"], linewidth=2.2, label=f"TV-STFN OOF (AUROC = {roc_auc:.3f})")
    axes[0].plot([0, 1], [0, 1], color=COLORS["gray"], linestyle="--", linewidth=1, label="Chance")
    axes[0].set(xlabel="False positive rate", ylabel="True positive rate", title="A  ROC curve", xlim=(0, 1), ylim=(0, 1.02))
    axes[0].legend(frameon=False, loc="lower right", fontsize=8)
    axes[1].plot(recall, precision, color=COLORS["red"], linewidth=2.2, label=f"TV-STFN OOF (AUPRC = {pr_auc:.3f})")
    axes[1].axhline(prevalence, color=COLORS["gray"], linestyle="--", linewidth=1, label=f"Positive prevalence = {prevalence:.3f}")
    axes[1].set(xlabel="Recall", ylabel="Precision", title="B  Precision-recall curve", xlim=(0, 1), ylim=(0, 1.02))
    axes[1].legend(frameon=False, loc="lower left", fontsize=8)
    fig.suptitle("Frozen ten-fold out-of-fold predictions (n = 6,941)", fontweight="bold", y=1.02)
    fig.tight_layout()
    save(fig, "Fig4_ROC_PR_verified")


def scaffold() -> None:
    s = pd.read_csv(SCAFFOLD).iloc[0]
    labels = ["Global 10-fold CV", "Scaffold hold-out"]
    # Global values are the fold means recomputed from the same frozen OOF
    # prediction files used throughout the manuscript—not the unsupported
    # 0.9309 claim or a separate best-run summary.
    auroc = [0.8150397114388486, float(s["fixed_AUROC"])]
    f1 = [0.7384803575225639, float(s["fixed_F1"])]
    x = np.arange(2)
    width = 0.34
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    bars1 = ax.bar(x - width / 2, auroc, width, color=COLORS["blue"], label="AUROC")
    bars2 = ax.bar(x + width / 2, f1, width, color=COLORS["orange"], label="F1")
    ax.set_xticks(x, labels)
    ax.set_ylim(0.60, 0.90)
    ax.set_ylabel("Score")
    ax.set_title("Global OOF and scaffold-disjoint hold-out metrics")
    ax.legend(frameon=False)
    for bars in (bars1, bars2):
        for bar in bars:
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.006, f"{bar.get_height():.3f}", ha="center", va="bottom")
    ax.text(1, 0.615, "test n = 695; fixed -6.0 threshold", ha="center", fontsize=8, color=COLORS["gray"])
    fig.tight_layout()
    save(fig, "Fig5_scaffold_validation_verified")


def cliff_scatter() -> None:
    df = pd.read_csv(CLIFF)
    df = df[df["tanimoto"] >= 0.85].copy()
    ranking = float(df["ranking_correct"].mean())
    gap_mae = float(df["abs_delta_error"].mean())
    fig, ax = plt.subplots(figsize=(5.2, 4.2))
    hb = ax.hexbin(df["true_delta_signed"], df["pred_delta_signed"], gridsize=45, mincnt=1, cmap="viridis", linewidths=0)
    lim = float(max(np.abs(df["true_delta_signed"]).max(), np.abs(df["pred_delta_signed"]).max()))
    ax.plot([-lim, lim], [-lim, lim], color=COLORS["red"], linestyle="--", linewidth=1.2, label="Ideal gap preservation")
    ax.axhline(0, color=COLORS["gray"], linewidth=0.7)
    ax.axvline(0, color=COLORS["gray"], linewidth=0.7)
    ax.set(xlabel="Experimental pairwise difference in permeability (log Pe)", ylabel="Predicted pairwise difference (log Pe)", title="Dataset-wide activity-cliff analysis")
    ax.text(0.03, 0.97, f"Pairs = {len(df):,}\nRanking accuracy = {ranking:.3f}\nMean |gap error| = {gap_mae:.3f}", transform=ax.transAxes, va="top", ha="left", bbox={"facecolor": "white", "edgecolor": "#D1D5DB", "alpha": 0.9})
    ax.legend(frameon=False, loc="lower right")
    fig.colorbar(hb, ax=ax, label="Pair density")
    fig.tight_layout()
    save(fig, "Fig6_activity_cliffs_verified")


def source_stratified() -> None:
    df = pd.read_csv(SOURCE).sort_values("AUROC")
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    colors = [COLORS["orange"] if n < 100 else COLORS["blue"] for n in df["n"]]
    ax.barh(df["Source"], df["AUROC"], color=colors)
    ax.axvline(0.811, color=COLORS["red"], linestyle="--", linewidth=1.2, label="Pooled OOF AUROC")
    ax.set(xlabel="AUROC", ylabel="Publication source", title="Source-stratified performance of frozen OOF predictions", xlim=(0.45, 1.0))
    ax.legend(frameon=False, fontsize=8)
    for i, (_, row) in enumerate(df.iterrows()):
        ax.text(row["AUROC"] + 0.008, i, f"n={int(row['n'])}", va="center", fontsize=7)
    fig.tight_layout()
    save(fig, "FigS_source_stratified_verified")


def dft() -> None:
    names = ["CP1 (ID 7384)", "CP2 (ID 7387)"]
    values = [11.52, 10.39]
    fig, ax = plt.subplots(figsize=(4.8, 3.35))
    bars = ax.bar(names, values, color=[COLORS["red"], COLORS["blue"]], width=0.55)
    ax.set(ylabel="SMD transfer free-energy difference (kcal/mol)", title="Qualitative DFT/SMD solvent-transfer comparison (n = 2)", ylim=(0, 13))
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.25, f"{value:.2f}", ha="center", fontweight="bold")
    ax.text(0.5, -0.22, "Descriptive case study only; no correlation or statistical inference", transform=ax.transAxes, ha="center", fontsize=8, color=COLORS["gray"])
    fig.tight_layout()
    save(fig, "Fig8_DFT_qualitative_verified")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    style()
    data_distribution()
    roc_pr()
    scaffold()
    cliff_scatter()
    source_stratified()
    dft()
    print(f"Verified figures written to {OUT}")


if __name__ == "__main__":
    main()
